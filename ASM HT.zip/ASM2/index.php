<?php
require_once 'config.php';
checkLogin();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hệ Thống Quản Lý Thư Viện</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }
        .sidebar a {
            color: #fff;
            text-decoration: none;
            padding: 10px 15px;
            display: block;
        }
        .sidebar a:hover {
            background-color: #495057;
        }
        .content {
            padding: 20px;
        }
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-2 sidebar p-0">
                <div class="p-3 text-white">
                    <h4>Thư Viện</h4>
                </div>
                <nav>
                    <a href="index.php"><i class="fas fa-home"></i> Trang chủ</a>
                    <?php if ($_SESSION['role'] === 'admin' || $_SESSION['role'] === 'librarian'): ?>
                    <a href="books/"><i class="fas fa-book"></i> Quản lý sách</a>
                    <a href="borrowings/"><i class="fas fa-exchange-alt"></i> Mượn trả</a>
                    <a href="fines/"><i class="fas fa-money-bill"></i> Quản lý phạt</a>
                    <?php endif; ?>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                    <a href="users/"><i class="fas fa-users"></i> Quản lý người dùng</a>
                    <a href="publishers/"><i class="fas fa-building"></i> Nhà xuất bản</a>
                    <a href="reports/"><i class="fas fa-chart-bar"></i> Báo cáo</a>
                    <?php endif; ?>
                    <a href="profile.php"><i class="fas fa-user"></i> Thông tin cá nhân</a>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Đăng xuất</a>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-10 content">
                <h2 class="mb-4">Tổng quan</h2>
                
                <div class="row">
                    <!-- Thống kê sách -->
                    <div class="col-md-3">
                        <div class="card bg-primary text-white">
                            <div class="card-body">
                                <h5 class="card-title">Tổng số sách</h5>
                                <?php
                                $stmt = $pdo->query("SELECT COUNT(*) as total FROM books");
                                $result = $stmt->fetch();
                                ?>
                                <p class="card-text display-4"><?php echo $result['total']; ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Thống kê sách đang mượn -->
                    <div class="col-md-3">
                        <div class="card bg-warning text-white">
                            <div class="card-body">
                                <h5 class="card-title">Sách đang mượn</h5>
                                <?php
                                $stmt = $pdo->query("SELECT COUNT(*) as total FROM borrowings WHERE status = 'borrowed'");
                                $result = $stmt->fetch();
                                ?>
                                <p class="card-text display-4"><?php echo $result['total']; ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Thống kê sách quá hạn -->
                    <div class="col-md-3">
                        <div class="card bg-danger text-white">
                            <div class="card-body">
                                <h5 class="card-title">Sách quá hạn</h5>
                                <?php
                                $stmt = $pdo->query("SELECT COUNT(*) as total FROM borrowings WHERE status = 'overdue'");
                                $result = $stmt->fetch();
                                ?>
                                <p class="card-text display-4"><?php echo $result['total']; ?></p>
                            </div>
                        </div>
                    </div>

                    <!-- Thống kê thành viên -->
                    <div class="col-md-3">
                        <div class="card bg-success text-white">
                            <div class="card-body">
                                <h5 class="card-title">Thành viên</h5>
                                <?php
                                $stmt = $pdo->query("SELECT COUNT(*) as total FROM users WHERE role = 'member'");
                                $result = $stmt->fetch();
                                ?>
                                <p class="card-text display-4"><?php echo $result['total']; ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Sách mượn nhiều nhất -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Sách mượn nhiều nhất</h5>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Tên sách</th>
                                            <th>Số lần mượn</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $stmt = $pdo->query("
                                            SELECT b.title, COUNT(*) as borrow_count 
                                            FROM borrowings br 
                                            JOIN books b ON br.book_id = b.id 
                                            GROUP BY b.id 
                                            ORDER BY borrow_count DESC 
                                            LIMIT 5
                                        ");
                                        while ($row = $stmt->fetch()) {
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                                            echo "<td>" . $row['borrow_count'] . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Sách quá hạn gần đây -->
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">
                                <h5>Sách quá hạn gần đây</h5>
                            </div>
                            <div class="card-body">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Tên sách</th>
                                            <th>Ngày hết hạn</th>
                                            <th>Người mượn</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $stmt = $pdo->query("
                                            SELECT b.title, br.due_date, u.full_name 
                                            FROM borrowings br 
                                            JOIN books b ON br.book_id = b.id 
                                            JOIN users u ON br.user_id = u.id 
                                            WHERE br.status = 'overdue' 
                                            ORDER BY br.due_date DESC 
                                            LIMIT 5
                                        ");
                                        while ($row = $stmt->fetch()) {
                                            echo "<tr>";
                                            echo "<td>" . htmlspecialchars($row['title']) . "</td>";
                                            echo "<td>" . $row['due_date'] . "</td>";
                                            echo "<td>" . htmlspecialchars($row['full_name']) . "</td>";
                                            echo "</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 