-- Tạo cơ sở dữ liệu
CREATE DATABASE IF NOT EXISTS library_management;
USE library_management;

-- Bảng người dùng
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('admin', 'librarian', 'member') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng sách
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(100) NOT NULL,
    isbn VARCHAR(13) NOT NULL UNIQUE,
    category VARCHAR(50) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    available_quantity INT NOT NULL DEFAULT 1,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng mượn sách
CREATE TABLE borrowings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    user_id INT NOT NULL,
    borrow_date DATE NOT NULL,
    due_date DATE NOT NULL,
    return_date DATE,
    status ENUM('borrowed', 'returned', 'overdue') NOT NULL DEFAULT 'borrowed',
    fine DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Bảng phạt
CREATE TABLE fines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    borrowing_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    reason TEXT NOT NULL,
    status ENUM('pending', 'paid') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (borrowing_id) REFERENCES borrowings(id)
);

-- Bảng nhà xuất bản
CREATE TABLE publishers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bảng liên kết sách-nhà xuất bản
CREATE TABLE book_publishers (
    book_id INT NOT NULL,
    publisher_id INT NOT NULL,
    publish_year INT,
    PRIMARY KEY (book_id, publisher_id),
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (publisher_id) REFERENCES publishers(id)
);

-- Thêm dữ liệu mẫu cho bảng users
INSERT INTO users (username, password, full_name, email, role) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator', 'admin@library.com', 'admin'),
('librarian1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Librarian One', 'librarian1@library.com', 'librarian'),
('member1', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Member One', 'member1@library.com', 'member');

-- Thêm dữ liệu mẫu cho bảng publishers
INSERT INTO publishers (name, address, phone, email) VALUES
('NXB Trẻ', '123 Đường ABC, Quận 1, TP.HCM', '0281234567', 'contact@nxbtre.com.vn'),
('NXB Kim Đồng', '456 Đường XYZ, Quận 3, TP.HCM', '0287654321', 'contact@nxbkimdong.com.vn');

-- Thêm dữ liệu mẫu cho bảng books
INSERT INTO books (title, author, isbn, category, quantity, available_quantity, description) VALUES
('Đắc Nhân Tâm', 'Dale Carnegie', '9786048866835', 'Self-help', 5, 5, 'Sách về nghệ thuật đối nhân xử thế'),
('Nhà Giả Kim', 'Paulo Coelho', '9786048866836', 'Fiction', 3, 3, 'Tiểu thuyết về hành trình tìm kiếm ý nghĩa cuộc sống'),
('Tôi Thấy Hoa Vàng Trên Cỏ Xanh', 'Nguyễn Nhật Ánh', '9786048866837', 'Fiction', 4, 4, 'Tiểu thuyết về tuổi thơ');

-- Liên kết sách với nhà xuất bản
INSERT INTO book_publishers (book_id, publisher_id, publish_year) VALUES
(1, 1, 2020),
(2, 1, 2021),
(3, 2, 2019); 