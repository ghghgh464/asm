CREATE TABLE products (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category_id INT(11),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

INSERT INTO categories (name) VALUES ('Electronics'), ('Books'), ('Clothing');

INSERT INTO products (name, description, price, category_id) VALUES
('Laptop XYZ', 'A powerful laptop for work and play.', 1200.00, 1),
('The Hitchhiker's Guide to the Galaxy', 'A comedy science fiction series.', 15.50, 2),
('T-Shirt Basic', 'Comfortable cotton t-shirt.', 20.00, 3),
('Smartphone ABC', 'Latest model smartphone with great camera.', 800.00, 1),
('1984 by George Orwell', 'A dystopian social science fiction novel.', 10.00, 2); 