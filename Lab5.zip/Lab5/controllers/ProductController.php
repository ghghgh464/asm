<?php

require_once __DIR__ . '/../models/Product.php';

class ProductController {
    private $product;

    public function __construct($db){
        $this->product = new Product($db);
    }

    public function index(){
        // Get all products
        $stmt = $this->product->readAll();
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Load the view for product list
        include __DIR__ . '/../views/product/list.php';
    }

    public function detail($id){
        $this->product->id = $id;

        // Read single product
        if ($this->product->readOne()) {
            // Product found, load detail view
            $product = $this->product; // Pass product object to view
            include __DIR__ . '/../views/product/detail.php';
        } else {
            // Product not found
            http_response_code(404);
            echo "Product not found."; // Simple error message
        }
    }

     public function category($category_id){
        // Get products by category
        $stmt = $this->product->readByCategory($category_id);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Load the view for product list (can reuse list view)
        include __DIR__ . '/../views/product/list.php';
    }
} 