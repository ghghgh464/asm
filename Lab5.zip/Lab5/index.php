<?php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/controllers/ProductController.php';

// Create database connection
// Assuming $conn from db.php is available globally or modify to use a Database class instance
// require_once __DIR__ . '/path/to/your/Database.php'; // If you have a Database class
// $database = new Database();
// $conn = $database->getConnection();

// For simplicity, directly use $conn from included db.php

// Create ProductController instance
$productController = new ProductController($conn);

// Get the requested action and ID/category from URL parameters
$action = isset($_GET['action']) ? $_GET['action'] : 'index';
$id = isset($_GET['id']) ? $_GET['id'] : null;
$category_id = isset($_GET['category_id']) ? $_GET['category_id'] : null;

// Routing
switch ($action) {
    case 'index':
        $productController->index();
        break;
    case 'detail':
        if ($id !== null) {
            $productController->detail($id);
        } else {
            // Handle missing ID
            http_response_code(400); // Bad Request
            echo "Product ID is missing.";
        }
        break;
    case 'category':
         if ($category_id !== null) {
            $productController->category($category_id);
        } else {
            // Handle missing category ID
            http_response_code(400); // Bad Request
            echo "Category ID is missing.";
        }
        break;
    // Add more cases for other actions if needed (e.g., create, update, delete)
    default:
        // Default to product list if action is not recognized
        $productController->index();
        break;
} 