<!DOCTYPE html>
<html>
<head>
    <title>Product Detail</title>
</head>
<body>
    <?php if (isset($product)): ?>
        <h1><?php echo htmlspecialchars($product->name); ?></h1>
        <p><strong>Price:</strong> $<?php echo htmlspecialchars(number_format($product->price, 2)); ?></p>
        <p><strong>Category:</strong> <?php echo htmlspecialchars($product->category_id); ?></p>
        <p><strong>Description:</strong> <?php echo htmlspecialchars($product->description); ?></p>
        <p><a href="index.php">Back to Product List</a></p>
    <?php else: ?>
        <p>Product details not available.</p>
    <?php endif; ?>
</body>
</html> 