<?php

require_once __DIR__ . '/../config/db.php';

class Product {
    private $conn;
    private $table_name = "products";

    public $id;
    public $name;
    public $description;
    public $price;
    public $category_id;
    public $created_at;

    public function __construct($db){
        $this->conn = $db;
    }

    // Read all products
    public function readAll(){
        $query = "SELECT p.id, p.name, p.description, p.price, c.name as category_name 
                  FROM " . $this->table_name . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  ORDER BY p.created_at DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt;
    }

    // Read single product by ID
    public function readOne(){
        // Validate ID
        if (!filter_var($this->id, FILTER_VALIDATE_INT)) {
            return false; // Invalid ID
        }

        $query = "SELECT p.id, p.name, p.description, p.price, c.name as category_name 
                  FROM " . $this->table_name . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.id = :id
                  LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id, PDO::PARAM_INT);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($row) {
            $this->name = $row['name'];
            $this->description = $row['description'];
            $this->price = $row['price'];
            $this->category_id = $row['category_name']; // Storing category name here for simplicity
            return true;
        }
        
        return false; // Product not found
    }

    // Load products by category
    public function readByCategory($category_id){
        // Validate category ID
         if (!filter_var($category_id, FILTER_VALIDATE_INT)) {
            return false; // Invalid category ID
        }

        $query = "SELECT p.id, p.name, p.description, p.price, c.name as category_name 
                  FROM " . $this->table_name . " p
                  LEFT JOIN categories c ON p.category_id = c.id
                  WHERE p.category_id = :category_id
                  ORDER BY p.created_at DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt;
    }
} 