<?php
require_once 'Database.php';


$host = 'localhost';
$dbname = 'mmo';
$username = 'root';
$password = '';

$database = new Database($host, $dbname, $username, $password);


$connection = $database->connect();

$database->disconnect();
?> 