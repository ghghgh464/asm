<?php

class Model {
    public function getAll() {
        return [
            [
                'id' => 1,
                'name' => 'John Doe',
                'email' => 'john@example.com',
                'phone' => '1234567890'
            ],
            

        ]
    }
}