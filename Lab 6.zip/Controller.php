<?php
require_once "Model/Product.php";
require_once "Model/Database.php";

class PageController {
    private $productModel;
    private $dbConnection;

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
        $this->productModel = new Product($this->dbConnection);
    }

    public function renderPage($page) {
        include 'views/header.php';

        switch ($page) {
            case 'product':
                // Pagination parameters
                $itemsPerPage = 10; // You can adjust this
                $currentPage = $_GET['page_num'] ?? 1;
                $offset = ($currentPage - 1) * $itemsPerPage;

                // Get paginated products and total count
                $paginationData = $this->productModel->getPaginatedProducts($itemsPerPage, $offset);
                $products = $paginationData['products'];
                $totalProducts = $paginationData['total'];
                $totalPages = ceil($totalProducts / $itemsPerPage);

                include 'views/product.php';
                break;
            case 'cart':
                include 'views/cart.php';
                break;
            case 'checkout':
                include 'views/checkout.php';
                break;
            case 'search':
                $searchTerm = $_GET['term'] ?? '';
                $products = $this->productModel->searchProducts($searchTerm);
                // We don't have total for search results in this simple implementation, 
                // so we'll pass null for totalProducts and totalPages
                $totalProducts = null;
                $totalPages = null;
                include 'views/product.php';
                break;
            default:
                $products = $this->productModel->getAllProducts();
                 // We don't have total for all products in this simple implementation,
                 // so we'll pass null for totalProducts and totalPages
                $totalProducts = null;
                $totalPages = null;
                include 'views/home.php';
                break;
        }

        include 'views/footer.php';
    }
}
?>
