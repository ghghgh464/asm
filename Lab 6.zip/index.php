<?php
require_once "controller/Controller.php";
require_once "Model/Database.php";


$host = 'localhost';
$dbname = 'mmo';
$username = 'root';
$password = '';

$db = new Database($host, $dbname, $username, $password);
$dbConnection = $db->connect();

$controller = new PageController($dbConnection);

$page = $_GET['page'] ?? 'home';
$controller->renderPage($page);

$db->disconnect();
?>
