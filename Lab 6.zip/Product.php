<?php
class Product {
    private $dbConnection; 

    public function __construct($dbConnection) {
        $this->dbConnection = $dbConnection;
    }

    public function getAllProducts() {
        try {
            $stmt = $this->dbConnection->query("SELECT * FROM products"); 
            return $stmt->fetchAll(PDO::FETCH_ASSOC); 
        } catch (PDOException $e) {
            echo "Lỗi truy vấn dữ liệu: " . $e->getMessage() . "\n";
            return []; 
        }
    }

    public function getProductById($id) {
        try {
            $stmt = $this->dbConnection->prepare("SELECT * FROM products WHERE id = :id");
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo "Lỗi truy vấn dữ liệu: " . $e->getMessage() . "\n";
            return null; 
        }
    }

    // New method to search products
    public function searchProducts($searchTerm) {
        try {
            // Using prepared statement with LIKE for safe searching
            $query = "SELECT * FROM products WHERE name LIKE :searchTerm OR description LIKE :searchTerm";
            $stmt = $this->dbConnection->prepare($query);
            // Bind the parameter, adding wildcards for LIKE search
            $likeTerm = "%" . $searchTerm . "%";
            $stmt->bindParam(':searchTerm', $likeTerm, PDO::PARAM_STR);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            echo "Lỗi tìm kiếm sản phẩm: " . $e->getMessage() . "\n";
            return [];
        }
    }

    // New method for pagination
    public function getPaginatedProducts($limit, $offset) {
        try {
            // Prepared statement with LIMIT and OFFSET for pagination
            $query = "SELECT * FROM products LIMIT :limit OFFSET :offset";
            $stmt = $this->dbConnection->prepare($query);
            // Bind parameters as integers
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Get total number of products for pagination links
            $totalQuery = "SELECT COUNT(*) FROM products";
            $totalStmt = $this->dbConnection->query($totalQuery);
            $totalProducts = $totalStmt->fetchColumn();

            return ['products' => $products, 'total' => $totalProducts];
        } catch (PDOException $e) {
            echo "Lỗi phân trang sản phẩm: " . $e->getMessage() . "\n";
            return ['products' => [], 'total' => 0];
        }
    }
}
?> 