<?php
require_once "Model/Product.php";

class PageController {
    private $productModel;

    public function __construct() {
        $this->productModel = new Product();
    }

    public function renderPage($page) {
        include 'views/header.php';

        switch ($page) {
            case 'product':
                $products = $this->productModel->getAllProducts();
                include 'views/product.php';
                break;
            case 'cart':
                include 'views/cart.php';
                break;
            case 'checkout':
                include 'views/checkout.php';
                break;
            default:
                $products = $this->productModel->getAllProducts();
                include 'views/home.php';
                break;
        }

        include 'views/footer.php';
    }
}
?>
