<section class="products">
    <h2>Sản phẩm của chúng tôi</h2>
    <div class="product-grid">
        <?php foreach ($products as $product): ?>
            <div class="product-card">
                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                <p class="price"><?php echo number_format($product['price']); ?> VNĐ</p>
                <p class="description"><?php echo htmlspecialchars($product['description']); ?></p>
                <a href="?page=cart&action=add&id=<?php echo $product['id']; ?>" class="btn">Thêm vào giỏ hàng</a>
            </div>
        <?php endforeach; ?>
    </div>
</section>
