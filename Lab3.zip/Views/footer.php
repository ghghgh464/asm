</main>
    <footer>
        <p>&copy; 2025 MMO Services. All rights reserved.</p>
    </footer>
</body>
</html>
