<?php
require_once "controller/Controller.php";
$controller = new PageController();
$page = $_GET['page'] ?? 'home';
$controller->renderPage($page);
?>
