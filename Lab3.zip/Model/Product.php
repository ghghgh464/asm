<?php
class Product {
    private $db;

    public function __construct() {
        // Kết nối database ở đây
    }

    public function getAllProducts() {
        // Trả về danh sách sản phẩm
        return [
            [
                'id' => 1,
                'name' => 'Sản phẩm 1',
                'price' => 100000,
                'description' => 'Mô tả sản phẩm 1'
            ],
            [
                'id' => 2,
                'name' => 'Sản phẩm 2',
                'price' => 200000,
                'description' => 'Mô tả sản phẩm 2'
            ],
            [
                'id' => 3,
                'name' => 'Sản phẩm 3',
                'price' => 300000,
                'description' => 'Mô tả sản phẩm 3'
            ]
        ];
    }

    public function getProductById($id) {
        // Lấy thông tin chi tiết sản phẩm theo ID
        $products = $this->getAllProducts();
        foreach ($products as $product) {
            if ($product['id'] == $id) {
                return $product;
            }
        }
        return null;
    }
}
?> 