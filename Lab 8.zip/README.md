# Lab 8 - Product Management System

A simple PHP-based product management system that allows users to add, edit, and delete products with images.

## Features

- Add new products with images
- Edit existing products
- Delete products
- Responsive design using Bootstrap 5
- Image upload and management
- MySQL database integration

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- mod_rewrite enabled (for Apache)

## Installation

1. Create a new database using the provided `database.sql` file:
   ```sql
   mysql -u root -p < database.sql
   ```

2. Configure the database connection in `config.php`:
   ```php
   $host = 'localhost';
   $dbname = 'lab8_db';
   $username = 'root';
   $password = '';
   ```

3. Make sure the `uploads` directory is writable:
   ```bash
   chmod 777 uploads
   ```

4. Access the application through your web browser:
   ```
   http://localhost/Lab8/
   ```

## Usage

1. Add a new product:
   - Fill out the product form with name, price, description, and image
   - Click "Add Product"

2. Edit a product:
   - Click the "Edit" button on any product card
   - Modify the product details
   - Click "Update Product"

3. Delete a product:
   - Click the "Delete" button on any product card
   - Confirm the deletion

## Security Features

- Input validation and sanitization
- Secure file upload handling
- PDO prepared statements for database queries
- XSS prevention
- CSRF protection

## File Structure

```
Lab8/
├── config.php          # Database configuration
├── database.sql        # Database structure
├── edit.php           # Product edit page
├── index.php          # Main page
├── process.php        # Form processing
├── uploads/           # Image upload directory
└── README.md          # This file
``` 