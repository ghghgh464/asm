<?php
require_once 'config.php';

// Tạo thư mục uploads nếu chưa tồn tại
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

// Xử lý Thêm Sản Phẩm
if (isset($_POST['add_product'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    
    // Xử lý upload file
    $target_dir = "uploads/";
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $image_name = uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $image_name;
    
    // Kiểm tra xem file có phải là hình ảnh thật không
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check === false) {
        die("File không phải là hình ảnh.");
    }
    
    // Kiểm tra kích thước file (tối đa 5MB)
    if ($_FILES["image"]["size"] > 5000000) {
        die("Xin lỗi, file của bạn quá lớn.");
    }
    
    // Chỉ cho phép các định dạng file nhất định
    if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
        die("Xin lỗi, chỉ chấp nhận file JPG, JPEG, PNG & GIF.");
    }
    
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO products (name, price, description, image) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $price, $description, $image_name]);
            header("Location: index.php");
            exit();
        } catch(PDOException $e) {
            echo "Lỗi: " . $e->getMessage();
        }
    } else {
        echo "Xin lỗi, đã xảy ra lỗi khi upload file.";
    }
}

// Xử lý Xóa Sản Phẩm
if (isset($_POST['delete_product'])) {
    $product_id = $_POST['product_id'];
    
    try {
        // Lấy tên file hình ảnh trước khi xóa
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();
        
        // Xóa khỏi cơ sở dữ liệu
        $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        
        // Xóa file hình ảnh
        if ($product && file_exists("uploads/" . $product['image'])) {
            unlink("uploads/" . $product['image']);
        }
        
        header("Location: index.php");
        exit();
    } catch(PDOException $e) {
        echo "Lỗi: " . $e->getMessage();
    }
}

// Xử lý Sửa Sản Phẩm
if (isset($_POST['edit_product'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    
    try {
        if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {
            // Xử lý upload hình ảnh mới
            $target_dir = "uploads/";
            $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
            $image_name = uniqid() . '.' . $imageFileType;
            $target_file = $target_dir . $image_name;
            
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                // Xóa hình ảnh cũ
                $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
                $stmt->execute([$id]);
                $old_image = $stmt->fetch();
                if ($old_image && file_exists("uploads/" . $old_image['image'])) {
                    unlink("uploads/" . $old_image['image']);
                }
                
                // Cập nhật với hình ảnh mới
                $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, description = ?, image = ? WHERE id = ?");
                $stmt->execute([$name, $price, $description, $image_name, $id]);
            }
        } else {
            // Cập nhật không thay đổi hình ảnh
            $stmt = $pdo->prepare("UPDATE products SET name = ?, price = ?, description = ? WHERE id = ?");
            $stmt->execute([$name, $price, $description, $id]);
        }
        
        header("Location: index.php");
        exit();
    } catch(PDOException $e) {
        echo "Lỗi: " . $e->getMessage();
    }
}
?> 